package com.example.backendproj.model;


public enum RoomType {
    DELUX_ROOM,
    AC_ROOM,
    FOUR_BED_AC_ROOM,
    FOUR_BED_NON_AC_ROOM,
    THREE_DOUBLE_BED_ROOM,
    TWO_DOUBLE_BED_ROOM,
    ONE_DOUBLE_ONE_SINGLE_BED_ROOM,
    ONE_MEDIUM_BED_ROOM,
    THREE_SINGLE_BED_ROOM_AC
}
