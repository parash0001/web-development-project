package com.example.backendproj.pojo;



import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrderItemPOJO {
    private String menuItemId; // Reference to Kitchen
    private int quantity;


}
